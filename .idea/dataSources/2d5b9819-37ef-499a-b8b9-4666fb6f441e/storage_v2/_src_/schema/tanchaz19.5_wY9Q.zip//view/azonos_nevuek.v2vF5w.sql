create view azonos_nevuek as
  select `tanchaz19`.`karszalagok`.`nev` AS `nev`, count(`tanchaz19`.`karszalagok`.`nev`) AS `COUNT(nev)`
  from `tanchaz19`.`karszalagok`
  group by `tanchaz19`.`karszalagok`.`nev`
  having count(`tanchaz19`.`karszalagok`.`nev`) > 1;

