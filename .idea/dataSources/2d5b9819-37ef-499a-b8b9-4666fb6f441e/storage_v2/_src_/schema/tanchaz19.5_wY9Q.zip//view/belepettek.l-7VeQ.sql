create view belepettek as
  select `k`.`nev` AS `nev`, `k`.`megjegyzes` AS `megjegyzes`, `k`.`miko` AS `miko`, `c`.`cegnev` AS `ceg`
  from (`tanchaz19`.`karszalagok` `k` join `tanchaz19`.`ceglista` `c`)
  where `k`.`belepett` = 1
    and `k`.`cegnev` = `c`.`sorsz`
  order by `k`.`nev`;

