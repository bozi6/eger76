create view duplikalt as
  select `tanchaz19`.`karszalagok`.`nev`                AS `nev`,
         count(`tanchaz19`.`karszalagok`.`nev`)         AS `db`,
         `tanchaz19`.`karszalagok`.`szul_datum`         AS `szul_datum`,
         count(`tanchaz19`.`karszalagok`.`szul_datum`)  AS `szuldate`,
         `tanchaz19`.`karszalagok`.`programresz`        AS `programresz`,
         count(`tanchaz19`.`karszalagok`.`programresz`) AS `progrdb`
  from `tanchaz19`.`karszalagok`
  group by `tanchaz19`.`karszalagok`.`nev`, `tanchaz19`.`karszalagok`.`szul_datum`,
           `tanchaz19`.`karszalagok`.`programresz`
  having count(`tanchaz19`.`karszalagok`.`nev`) > 1
     and count(`tanchaz19`.`karszalagok`.`szul_datum`) > 1
     and count(`tanchaz19`.`karszalagok`.`programresz`) > 1;

