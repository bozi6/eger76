create view mindenki as
  select `k`.`sorsz`       AS `sorsz`,
         `k`.`nev`         AS `nev`,
         `k`.`szul_datum`  AS `szul_datum`,
         `k`.`cegnev`      AS `cegid`,
         `c`.`cegnev`      AS `cegnev`,
         `k`.`besorolas`   AS `besorolas`,
         `k`.`programresz` AS `programresz`,
         `k`.`megjegyzes`  AS `megjegyzes`,
         `k`.`belepett`    AS `belepett`,
         `k`.`miko`        AS `miko`,
         `k`.`szdarab`     AS `szdarab`,
         `k`.`gyszdarab`   AS `gyszdarab`
  from (`tanchaz19`.`karszalagok` `k` join `tanchaz19`.`ceglista` `c`)
  where `c`.`sorsz` = `k`.`cegnev`;

